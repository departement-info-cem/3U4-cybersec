(function() {
    function n(n) {
        for (var u = n.split("."), t = window, i, r = 0; r < u.length; r++)
            i = u[r],
            t[i] || (t[i] = {}),
            t = t[i]
    }
    function u() {
        var i, r, n, t;
        if (!document.cookie)
            return {};
        for (i = {},
        r = document.cookie.split(";"),
        n = 0; n < r.length; n++)
            t = r[n].split("="),
            t.length === 2 && (i[t[0].trim()] = t[1].trim());
        return i
    }
    function r(n) {
        var t = n.split(".")
          , i = parseInt(t[0] || 0, 10)
          , r = parseInt(t[1] || 0, 10)
          , u = parseInt(t[2] || 0, 10);
        return {
            Major: i,
            Minor: r,
            Revision: u
        }
    }
    function f(n, t) {
        return (typeof n == "string" && (n = r(n)),
        typeof t == "string" && (t = r(t)),
        n.Major !== t.Major) ? n.Major < t.Major : n.Minor !== t.Minor ? n.Minor < t.Minor : n.Revision <= t.Revision
    }
    var t, i;
    window.Skytech || (window.Skytech = {});
    window.Skytech.AppNative || (window.Skytech.AppNative = {});
    t = u();
    n("Skytech.Commun.Utils.Support");
    i = t.Platform;
    Skytech.Commun.Utils.Support.Android = i === "android";
    Skytech.Commun.Utils.Support.IOS = i === "ios";
    Skytech.Commun.Utils.Support.AppVersion = t.AppVersion;
    Skytech.Commun.Utils.Support.IsMinimumVersion = function(n, t) {
        var i;
        return (Skytech.Commun.Utils.Support.Android ? i = t : Skytech.Commun.Utils.Support.IOS && (i = n),
        !i) ? !0 : f(i, Skytech.Commun.Utils.Support.AppVersion)
    }
    ;
    n("Skytech.Commun.UI.Utils");
    Skytech.Commun.UI.Utils.ShowPopupPermission = function() {}
    ;
    n("Skytech.Commun.Application.ClientConfig.Dictio.COMMUN")
}
)(),
function() {
    function i(n, t) {
        for (var o = n.split("."), s = t.split("."), h = Math.max(o.length, s.length), i = 0; i < h; i++) {
            var r = parseInt(o[i], 10)
              , u = parseInt(s[i], 10)
              , f = !r && r !== 0
              , e = !u && u !== 0;
            if (f || e)
                return f && !e ? !1 : !f && e ? !0 : !1;
            if (r !== u)
                return r > u ? !0 : !1
        }
        return !0
    }
    function n(n) {
        function t(t) {
            $(".biometry-parts .biometry-part", n).hide();
            var r = f === "face" ? "sensor-face" : "sensor-fingerprint"
              , i = $(".biometry-parts ." + r + "." + t, n);
            i.length ? i.show() : $(".biometry-parts ." + t, n).show()
        }
        var i, r, u, f;
        n.length && (i = $(".biometry-challenge-field", n).val(),
        i) && (r = $(".biometry-prompt", n).val(),
        r) && (u = $(".biometry-response-field", n),
        u.length) && (n.show(),
        $(".biometry-parts .biometry-part", n).hide(),
        $(".biometry-parts", n).show(),
        t("biometry-check-in-progress"),
        Ovx.Biometry.GetCapabilitiesAndState({}, function(i) {
            i && i.BiometrySetupComplete && (f = i.SensorType);
            i && i.KeyInStorage && i.BiometrySetupComplete ? t("biometry-available") : i.BiometrySetupComplete && !i.KeyInStorage ? t("biometry-cleared") : n.hide()
        }),
        $(".biometry-prompt-trigger", n).click(function() {
            Ovx.Biometry.SignData({
                Data: i,
                DataTransform: "utf8",
                Prompt: r
            }, function(i) {
                if (i && i.Success && i.Signature) {
                    u.val(i.Signature);
                    t("biometry-success");
                    var r = n.closest("form");
                    r.find("button[type=submit]").prop("disabled", !0);
                    setTimeout(function() {
                        r.submit()
                    }, 500)
                } else
                    i && i.UserCancelled || (i && i.ReaderLockedOut ? t("biometry-locked-out") : t("biometry-failure"))
            })
        }))
    }
    if (window.navigator && window.navigator.userAgent && /(^OVX | OVX$)$/.test(window.navigator.userAgent)) {
        window.Skytech || (window.Skytech = {});
        window.Skytech.Biometrie || (window.Skytech.Biometrie = {});
        var t = $.cookie("AppVersion");
        t && i(t, "3.6.0") && (document.addEventListener("DOMContentLoaded", function() {
            n($(".mobile-app-biometry-target:first"))
        }),
        window.Skytech.Biometrie.WebControl = function(t) {
            n($(t))
        }
        )
    }
}(),
function() {
    function t(t) {
        for (var f = null, i = t.Name.split("."), e = i[i.length - 1], o = t.GetParams || function(n, t) {
            return {
                Args: n,
                Callback: t
            }
        }
        , s = t.ShouldExecute || function() {
            return !0
        }
        , h = t.OnCallback || function(n, t) {
            n && n.call(null, t)
        }
        , r = window.Ovx, u = 0; u < i.length - 1; u++)
            r[i[u]] = r[i[u]] || {},
            r = r[i[u]];
        r[e] = function c() {
            var i = o.apply(null, c.arguments);
            s(i) && (f = i.Callback,
            n(t.Name, i.Args || {}, t.UseContextSensitiveEncoding))
        }
        ;
        r[e + "CallBack"] = function(n) {
            h(f, n);
            f = null
        }
    }
    function n(n, t, i) {
        var f, e, o, r;
        if (i = i === !0,
        u)
            if (window && window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.ovx)
                window.webkit.messageHandlers.ovx.postMessage({
                    Command: n,
                    Params: t
                });
            else {
                f = kt + n + "/";
                e = "?";
                for (o in t)
                    r = t[o],
                    i && (r = encodeURIComponent(r)),
                    f += e + o + "=" + r,
                    e = "&";
                ni(f)
            }
        else
            ti(n, t)
    }
    function gt(n, t) {
        if (u)
            throw new Error("Commandes synchrones non disponibles sur iOS");
        else {
            var f = JSON.stringify(t);
            if (!r)
                try {
                    return OvxNatif.ExecuteCommand(n, f)
                } catch (i) {
                    if (nt())
                        Skytech.Commun.Application.LogWorker.LogError("MOBILE_NATIF_0002", "Erreur lors de l'exécution d'une commande native sync. \r\n Commande: " + n + "\r\n Params: " + JSON.stringify(t) + "\r\n Erreur: " + i);
                    else
                        throw Error("Erreur lors de l'exécution d'une commande native sync. \r\n Commande: " + n + "\r\n Params: " + JSON.stringify(t) + "\r\n Erreur: " + i);
                }
        }
    }
    function ni(n) {
        var t = document.createElement("iframe");
        t.setAttribute("src", n);
        document.body.appendChild(t);
        document.body.removeChild(t)
    }
    function ti(n, t) {
        setTimeout(function() {
            var i = JSON.stringify(t), u;
            if (!r)
                try {
                    u = OvxNatif.ExecuteCommand(n, i);
                    u === "retry" && setTimeout(function() {
                        OvxNatif.ExecuteCommand(n, i)
                    }, 100)
                } catch (f) {
                    if (nt())
                        (!Skytech.Commun.Utils.Support.IsMinimumVersion || Skytech.Commun.Utils.Support.IsMinimumVersion("2.0.0", "3.0.2")) && Skytech.Commun.Application.LogWorker.LogError("MOBILE_NATIF_0001", "Erreur lors de l'exécution d'une commande native. \r\n Commande: " + n + "\r\n Params: " + JSON.stringify(t) + "\r\n Erreur: " + f);
                    else
                        throw Error("Erreur lors de l'exécution d'une commande native. \r\n Commande: " + n + "\r\n Params: " + JSON.stringify(t) + "\r\n Erreur: " + f);
                }
        }, 1)
    }
    function ii(n, t) {
        return t.split(".").reduce(function(n, t) {
            return n[t] ? n[t] : n
        }, n)
    }
    function bt(n) {
        var t = Skytech.Commun.Utils.LocalStorage.GetData("debug-codeUA", []);
        t.push({
            log: n,
            date: new Date
        });
        t = t.slice(Math.max(t.length - 20, 0));
        Skytech.Commun.Utils.LocalStorage.SetData("debug-codeUA", t, !1, {
            versionPersistant: !0
        })
    }
    function ri() {
        typeof Skytech != "undefined" && typeof Skytech.Analytics != "undefined" && Skytech.Analytics.send()
    }
    var at, vt, tt, it, e, rt, ut, ft, et, o, ot, st, s, h, c, ht, l, a, ct, v, y, p, w, b, k, i, d, g, lt, yt, pt, wt;
    window.Ovx = {};
    window.Ovx.IOS = {};
    window.Ovx.Android = {};
    var kt = "ovx://"
      , r = navigator.userAgent.toLowerCase().indexOf("debug") !== -1 && navigator.platform === "Win32" || window.unitTest
      , u = /iphone|ipad|ipod/gi.test(navigator.appVersion) || /iphone|ipad|ipod/gi.test(navigator.userAgent)
      , dt = /Android/gi.test(navigator.userAgent)
      , f = function() {
        return window.Skytech && Skytech.Commun && Skytech.Commun.Utils
    }
      , nt = function() {
        return f() && Skytech.Commun.Application && Skytech.Commun.Application.LogWorker
    };
    window.Ovx.Application = {};
    Ovx.Application.IsDebug = function() {
        return r
    }
    ;
    Ovx.Application.OnBecomeActive = function() {
        typeof Skytech == "object" && typeof Skytech.Commun == "object" && typeof Skytech.Commun.Application == "object" && typeof Skytech.Commun.Application.HeartbeatWorker == "object" && typeof Skytech.Commun.Application.HeartbeatWorker.Heartbeat == "function" && Skytech.Commun.Application.HeartbeatWorker.Heartbeat()
    }
    ;
    t({
        Name: "Application.DeviceStats",
        ShouldExecute: function() {
            return Skytech.Commun.Utils.Support.IsMinimumVersion("3.0.2", "3.0.2")
        }
    });
    Ovx.Application.SetOpenMioPageCallback = function(n) {
        at = n
    }
    ;
    Ovx.Application.OpenMioPageCallBack = function(n) {
        typeof at == "function" && at(n)
    }
    ;
    Ovx.Application.OpenMioPage = function(t, i) {
        n("Application.OpenMioPage", {
            Page: t,
            Destinataire: i
        })
    }
    ;
    Ovx.Application.SetGetLeaAutoLoginUrlCallback = function(n) {
        vt = n
    }
    ;
    Ovx.Application.GetLeaAutoLoginUrlCallBack = function(n) {
        typeof vt == "function" && vt(n)
    }
    ;
    Ovx.Application.GetLeaAutoLoginUrl = function(t) {
        n("Application.GetLeaAutoLoginUrl", {
            Url: t
        })
    }
    ;
    tt = null;
    Ovx.Application.SetUrlProtocolReceiveCallBack = function(n) {
        tt = n
    }
    ;
    Ovx.Application.UrlProtocolReceiveCallBack = function(n) {
        tt !== null && tt(n)
    }
    ;
    t({
        Name: "WebUI.OpenNewWindow",
        GetParams: function(n, t, i, r, u, f, e, o, s, h) {
            return {
                Args: {
                    Url: n,
                    DisplayNavigationBar: t ? "True" : "False",
                    DisplayAltNavigationBar: i ? "true" : "false",
                    DisplayToolbar: r ? "True" : "False",
                    UseWebKit: u ? "true" : "false",
                    UseExistingView: f ? "true" : "false",
                    ActionButtonOptions: e,
                    TextBtnBack: o,
                    TextBackAltNavbar: s
                },
                Callback: h
            }
        }
    });
    it = !1;
    t({
        Name: "WebUI.CloseWindow",
        GetParams: function(n, t, i) {
            return {
                Args: {
                    CloseAll: n ? "True" : "False",
                    ParamsCallback: i
                },
                Callback: t
            }
        },
        ShouldExecute: function() {
            return it ? !1 : (it = !0,
            !0)
        },
        OnCallback: function(n, t) {
            if (n) {
                var i = typeof t.HasClosedWindow != "undefined" && t.HasClosedWindow.toLowerCase() == "true";
                n(i)
            }
            it = !1
        }
    });
    t({
        Name: "WebUI.SetDefaultPage",
        GetParams: function(n) {
            return {
                Args: {
                    Url: n
                },
                Callback: null
            }
        }
    });
    t({
        Name: "WebUI.SetWindowOption",
        GetParams: function(n, t, i, r) {
            return {
                Args: {
                    DisplayNavigationBar: n ? "True" : "False",
                    DisplayToolbar: t ? "True" : "False",
                    DisplayActionButton: i,
                    TextBtnBack: r
                }
            }
        }
    });
    Ovx.WebUI.ResetSession = function() {
        f() && bt("ResetSession");
        n("WebUI.ResetSession", {})
    }
    ;
    Ovx.WebUI.ResetSessionCallBack = function() {}
    ;
    t({
        Name: "WebUI.Exit"
    });
    t({
        Name: "WebUI.Restart"
    });
    e = window.isOnline;
    Ovx.WebUI.IsAppOnline = function() {
        return typeof e != "undefined" ? e : navigator.onLine
    }
    ;
    rt = null;
    Ovx.WebUI.IsOnline = function(t) {
        rt = t;
        n("WebUI.IsOnline", {})
    }
    ;
    Ovx.WebUI.IsOnlineCallBack = function(n) {
        typeof n.IsOnline != "undefined" && (e = n.IsOnline === "True",
        typeof rt == "function" && rt(e))
    }
    ;
    Ovx.WebUI.OpenURLInDeviceBrowser = function(t) {
        u ? n("WebUI.NavigateToStore", {
            urlStore: t
        }, !0) : n("Android.OpenFile", {
            Url: t,
            ContentType: null
        })
    }
    ;
    Ovx.WebUI.NavigateToStore = function(t) {
        var i, r;
        t = typeof t == "string" ? t : null;
        u ? (i = t ? "https://itunes.apple.com/ca/genre/ios/id36?mt=8" : "https://itunes.apple.com/ca/app/omnivox-mobile/id721913649?mt=8&uo=4",
        Skytech.Commun.Utils.Support.IsMinimumVersion("3.9.0", null) ? n("WebUI.NavigateToStore", {
            query: t,
            urlStore: i
        }, !0) : window.location = i) : dt && (r = {
            query: t
        },
        n("WebUI.NavigateToStore", r))
    }
    ;
    Ovx.WebUI.SetAltNavigationBarOptions = function(t) {
        t = t || {};
        n("WebUI.SetAltNavigationBarOptions", t, !0)
    }
    ;
    Ovx.WebUI.Omnigarder = function(n) {
        nt() && Skytech.Commun.Application.LogWorker.LogError(n.CodeOmnigarde, n.DescriptionOmnigarde)
    }
    ;
    ut = null;
    Ovx.WebUI.OnMemoryWarning = function(n) {
        ut = n
    }
    ;
    Ovx.WebUI.OnMemoryWarningCallBack = function() {
        ut && ut.call(null)
    }
    ;
    ft = null;
    Ovx.WebUI.OnResize = function(n) {
        ft = n
    }
    ;
    Ovx.WebUI.OnResizeCallBack = function() {
        ft && ft.call(null)
    }
    ;
    Ovx.WebUI.OnWillEnterBackgroundCallBack = function() {
        ri()
    }
    ;
    window.Ovx.Storage = {};
    et = [];
    Ovx.Storage.SetCodeUserAgent = function(t, i, u) {
        var e = {}, o;
        e.Callback = i;
        e.Arguments = u;
        o = {
            Code: t
        };
        n("Storage.SetCodeUserAgent", o);
        r ? e.Callback && e.Callback.apply(null, e.Arguments) : e.TimeoutFailsafe = setTimeout(function() {
            setTimeout(function() {
                e.Callback && e.Callback.apply(null, e.Arguments);
                nt() && Skytech.Commun.Utils.Support.IsMinimumVersion("3.0.3", undefined) && Skytech.Commun.Application.LogWorker.LogWarning("Pas d'appel du callback de SetCodeUserAgent après 8 secondes.")
            }, 1e3)
        }, 7e3);
        f() && bt("SetCodeUserAgent (" + t + ")");
        et.push(e)
    }
    ;
    Ovx.Storage.SetCodeUserAgentCallBack = function(n) {
        typeof n.UserAgentRequete != "undefined" && (window.userAgentRequete = n.UserAgentRequete,
        f() && Skytech.Commun.Utils.Support.Initialize());
        et.forEach(function(n) {
            (clearTimeout(n.TimeoutFailsafe),
            n.Callback) && n.Callback.apply(null, n.Arguments)
        });
        et = []
    }
    ;
    Ovx.Storage.SetInfo = function(t, i) {
        var r = {
            Key: t,
            Value: i
        };
        n("Storage.SetInfo", r)
    }
    ;
    Ovx.Storage.SetInfoCallBack = function() {}
    ;
    o = null;
    Ovx.Storage.GetInfo = function(t, i) {
        o = i;
        var r = {
            Key: t
        };
        n("Storage.GetInfo", r)
    }
    ;
    Ovx.Storage.GetInfoCallBack = function(n) {
        o !== null && (o(n.Key, n.Value),
        o = null)
    }
    ;
    window.Ovx.Clipboard = {};
    Ovx.Clipboard.CopyToClipboard = function(t) {
        var i = {
            Text: t
        };
        n("Clipboard.CopyToClipboard", i)
    }
    ;
    window.Ovx.Display = {};
    Ovx.Display.SetLanguage = function(t) {
        var i = {};
        typeof t != "undefined" && (i.L = t);
        n("Display.SetLanguage", i)
    }
    ;
    t({
        Name: "Display.ViewAppSettings"
    });
    Ovx.Display.ViewCommunicationError = function(t) {
        var i = {};
        typeof t != "undefined" && (i.ErrorMode = t);
        n("Display.ViewCommunicationError", i)
    }
    ;
    ot = null;
    Ovx.Display.ViewDocument = function(t, i, r, u, f, e, o) {
        ot = o;
        var h = encodeURI(document.location.origin + "/Mobl/App/ErreurDocument")
          , s = {
            Url: t,
            TextBtnBack: i,
            TextTitrePopup: r,
            TextTitre: u,
            TextCancel: f,
            ErrorURL: h
        };
        typeof e != "undefined" && (s.L = e);
        n("Display.ViewDocument", s)
    }
    ;
    st = null;
    Ovx.Display.ViewDocumentCallBack = function(n) {
        if ((typeof st == "function" && st(n),
        window.Skytech && n && n.State === "Failed") && Skytech.Commun.Utils.Support.IsMinimumVersion("3.0.2", "3.0.2")) {
            if (n.State === "Failed" && (n.Reason === "ServerError" || n.Reason === "InvalidMimetype")) {
                var t = ot ? ot : n.MimeType && n.MimeType.split("/")[1] || n.MimeType;
                Ovx.WebUI.OpenNewWindow(encodeURIComponent(document.location.origin + "/Mobl/App/ErreurDocument?typeErreur=" + n.Reason + (t ? "&extension=" + t : "") + "&mimeType=" + encodeURIComponent(n.MimeType ? n.MimeType : "")), !1, !1, !1, !1, !1, "", Skytech.Commun.Application.ClientConfig.Dictio.COMMUN.MSG_0001, "")
            }
            n.State === "Failed" && n.Reason === "PermissionError" && Skytech.Commun.UI.Utils.ShowPopupPermission(Skytech.Commun.UI.Utils.TypeShowPopupPermission.DOWNLOAD)
        }
    }
    ;
    Ovx.Display.SetViewDocumentCallBack = function(n) {
        st = n
    }
    ;
    Ovx.Display.ViewLogin = function(t, i, r) {
        var u = {};
        typeof t != "undefined" && (u.L = t);
        typeof i != "undefined" && (u.TypeLogin = i);
        typeof r != "undefined" && (u.Identifiant = r);
        n("Display.ViewLogin", u)
    }
    ;
    Ovx.Display.ViewStudentEmployee = function(t) {
        var i = {};
        typeof t != "undefined" && (i.L = t);
        n("Display.ViewStudentEmployee", i)
    }
    ;
    Ovx.Display.ViewInfo = function(t) {
        var i = {};
        typeof t != "undefined" && (i.L = t);
        n("Display.ViewInfo", i)
    }
    ;
    Ovx.Display.Print = function(t) {
        var i = {
            Url: t
        };
        n("Display.Print", i)
    }
    ;
    Ovx.Display.Scanner = function(t, i) {
        s = i;
        n("Display.Scanner", {
            Instructions: t
        })
    }
    ;
    s = null;
    Ovx.Display.ScannerCallBack = function(n) {
        s && (s.call(null, n),
        s = null)
    }
    ;
    t({
        Name: "Display.Authenticate"
    });
    t({
        Name: "Display.SetBrightness"
    });
    t({
        Name: "Display.OpenCamera"
    });
    t({
        Name: "Biometry.GetCapabilities",
        UseContextSensitiveEncoding: !0
    });
    t({
        Name: "Biometry.GenerateSigningKey",
        UseContextSensitiveEncoding: !0
    });
    t({
        Name: "Biometry.SignData",
        UseContextSensitiveEncoding: !0
    });
    t({
        Name: "Biometry.GetState",
        UseContextSensitiveEncoding: !0
    });
    t({
        Name: "Biometry.SetSetupDone",
        UseContextSensitiveEncoding: !0
    });
    t({
        Name: "Biometry.GetCapabilitiesAndState",
        UseContextSensitiveEncoding: !0
    });
    t({
        Name: "Biometry.DeleteKey",
        UseContextSensitiveEncoding: !0
    });
    window.Ovx.IOS.Notification = {};
    h = null;
    Ovx.IOS.Notification.GetEnabledRemoteNotificationTypes = function(t) {
        h = t || null;
        n("IOS.Notification.GetEnabledRemoteNotificationTypes", {})
    }
    ;
    Ovx.IOS.Notification.GetEnabledRemoteNotificationTypesCallBack = function(n) {
        h !== null && (h.apply(null, [n]),
        h = null)
    }
    ;
    c = null;
    Ovx.IOS.Notification.RegisterForRemoteNotification = function(t, i) {
        c = i || null;
        var r = {
            DefaultNotificationType: t
        };
        n("IOS.Notification.RegisterForRemoteNotification", r)
    }
    ;
    Ovx.IOS.Notification.RegisterForRemoteNotificationCallBack = function(n) {
        c !== null && (c.apply(null, [n]),
        c = null)
    }
    ;
    ht = null;
    Ovx.IOS.Notification.SetOnReceivedNotificationCallBack = function(n) {
        ht = n
    }
    ;
    Ovx.IOS.Notification.OnReceivedNotification = function() {
        n("IOS.Notification.OnReceivedNotification", {})
    }
    ;
    Ovx.IOS.Notification.OnReceivedNotificationCallBack = function(n) {
        ht !== null && ht.apply(null, [n.NotificationUserInfo])
    }
    ;
    l = null;
    Ovx.IOS.Notification.SetBadge = function(t, i) {
        l = i || null;
        var r = {
            Number: t
        };
        n("IOS.Notification.SetBadge", r)
    }
    ;
    Ovx.IOS.Notification.SetBadgeCallBack = function(n) {
        l !== null && (l.apply(null, [n.Number]),
        l = null)
    }
    ;
    window.Ovx.Android.Notification = {};
    a = null;
    Ovx.Android.Notification.IsGooglePlayServicesAvailable = function(t) {
        if (f() && Skytech.Commun.Application.IsIntegrationTest && t) {
            t(!0);
            return
        }
        a = t || null;
        n("Android.Notification.IsGooglePlayServicesAvailable", {})
    }
    ;
    Ovx.Android.Notification.IsGooglePlayServicesAvailableCallBack = function(n) {
        a !== null && (a.apply(null, [n.IsAvailable, n.IsBackgroundRestricted]),
        a = null)
    }
    ;
    t({
        Name: "Android.Notification.Register"
    });
    ct = null;
    Ovx.Android.Notification.SetOnReceiveCallBack = function(n) {
        ct = n
    }
    ;
    Ovx.Android.Notification.OnReceive = function() {
        n("Android.Notification.OnReceive", {})
    }
    ;
    Ovx.Android.Notification.OnReceiveCallBack = function(n) {
        ct !== null && ct.apply(null, [n.NotificationMessage, n.NotificationOpenedApp])
    }
    ;
    window.Ovx.IOS.Purchase = {};
    v = null;
    Ovx.IOS.Purchase.GetProductInfo = function(t, i) {
        v = i || null;
        var r = {
            productIdentifiers: t
        };
        n("IOS.Purchase.GetProductInfo", r)
    }
    ;
    Ovx.IOS.Purchase.GetProductInfoCallBack = function(n) {
        v !== null && (v.apply(null, [n.ProductList, n.CanMakePayments]),
        v = null)
    }
    ;
    y = null;
    Ovx.IOS.Purchase.RequestPayment = function(t, i, r, u) {
        y = r || null;
        var f = {
            ProductIdentifier: t,
            ApplicationUsername: i,
            Quantity: u
        };
        n("IOS.Purchase.RequestPayment", f)
    }
    ;
    Ovx.IOS.Purchase.RequestPaymentCallBack = function(n) {
        y !== null && (y.apply(null, [n.CanMakePayments, n.IsCanceled]),
        y = null)
    }
    ;
    p = null;
    Ovx.IOS.Purchase.SetUpdatedPaymentCallback = function(n) {
        p = typeof n == "function" ? n : null
    }
    ;
    Ovx.IOS.Purchase.OnUpdatedPayment = function() {
        p !== null && p.apply(null, null)
    }
    ;
    w = null;
    Ovx.IOS.Purchase.GetListPaymentQueued = function(t) {
        w = t || null;
        n("IOS.Purchase.GetListPaymentQueued", {})
    }
    ;
    Ovx.IOS.Purchase.GetListPaymentQueuedCallBack = function(n) {
        w !== null && (w.apply(null, [n]),
        w = null)
    }
    ;
    b = null;
    Ovx.IOS.Purchase.FinishTransaction = function(t, i) {
        b = i || null;
        var r = {
            TransactionIdentifier: encodeURIComponent(t)
        };
        n("IOS.Purchase.FinishTransaction", r)
    }
    ;
    Ovx.IOS.Purchase.FinishTransactionCallBack = function() {
        b !== null && (b.apply(null, [{}]),
        b = null)
    }
    ;
    window.Ovx.Android.Purchase = {};
    k = null;
    Ovx.Android.Purchase.GetSkuDetails = function(t, i) {
        k = i || null;
        var r = {
            ProductIdentifiers: t
        };
        n("Android.Purchase.GetSkuDetails", r)
    }
    ;
    Ovx.Android.Purchase.GetSkuDetailsCallBack = function(n) {
        k !== null && (k.apply(null, [n.ProductList, n.ResponseCode]),
        k = null)
    }
    ;
    i = null;
    Ovx.Android.Purchase.RequestPayment = function(t, r, u) {
        i = u || null;
        var f = {
            ProductIdentifier: t,
            ApplicationUsername: r
        };
        n("Android.Purchase.RequestPayment", f)
    }
    ;
    Ovx.Android.Purchase.RequestPaymentCallBack = function(n) {
        i !== null && (n ? i.apply(null, [n.ResponseCode, n.InAppPurchaseData, n.InAppDataSignature, n.IsCanceled]) : i.apply(null, []),
        i = null)
    }
    ;
    d = null;
    Ovx.Android.Purchase.GetPurchases = function(t) {
        d = t || null;
        n("Android.Purchase.GetPurchases", {})
    }
    ;
    Ovx.Android.Purchase.GetPurchasesCallBack = function(n) {
        d !== null && (d.apply(null, [n.InAppPurchaseItemList, n.InAppPurchaseDataList, n.InAppDataSignatureList]),
        d = null)
    }
    ;
    g = null;
    Ovx.Android.Purchase.Consume = function(t, i) {
        g = i || null;
        var r = {
            PurchaseToken: t
        };
        n("Android.Purchase.Consume", r)
    }
    ;
    Ovx.Android.Purchase.ConsumeCallBack = function(n) {
        g !== null && (g.apply(null, [n.ResponseCode]),
        g = null)
    }
    ;
    t({
        Name: "Theme.SetTheme"
    });
    window.Ovx.Android.Device = {};
    lt = null;
    Ovx.Android.Device.SetRedirectNativeCommand = function(t) {
        if (!u && (lt === null || lt !== t)) {
            lt = t;
            var r = {
                Enabled: t
            }
              , i = "Android.Device.SetRedirectNativeCommand";
            wt && (i = "Device.SetRedirectNativeCommand");
            n(i, r)
        }
    }
    ;
    Ovx.Android.Device.OnTouch = function(n) {
        typeof Ovx.Android.Device.OnTouchHandle == "function" && Ovx.Android.Device.OnTouchHandle(n.CommandName)
    }
    ;
    Ovx.Android.Device.IsTablet = function() {
        if (window.unitTest)
            return window.userAgentRequete && window.userAgentRequete.indexOf("tablet") !== -1;
        if (r)
            return window.innerWidth > window.innerHeight;
        var n = JSON.parse(gt("Android.Device.IsTablet", {}));
        return n.IsTablet === "True"
    }
    ;
    t({
        Name: "Android.Device.HasCamera",
        ShouldExecute: function() {
            return !Skytech.Commun.Utils.Support.IOS && Skytech.Commun.Utils.Support.IsMinimumVersion("3.3.0", "3.3.0")
        }
    });
    t({
        Name: "Android.Device.OpenTimePicker"
    });
    t({
        Name: "Application.GetDeviceInfo"
    });
    Ovx.Android.SetFileChosenCallback = function(n) {
        yt = n
    }
    ;
    Ovx.Android.FileChosenCallBack = function(n) {
        n && n.Url && typeof yt == "function" && yt(n.Url)
    }
    ;
    Ovx.Android.OpenFile = function(t, i) {
        n("Android.OpenFile", {
            Url: t,
            ContentType: i
        })
    }
    ;
    Ovx.Android.SetDocumentOpenedCallback = function(n) {
        pt = n
    }
    ;
    Ovx.Android.DocumentOpenedCallBack = function() {
        typeof pt == "function" && pt()
    }
    ;
    Ovx.Android.OpenAppLink = function(t) {
        n("Android.OpenAppLink", {
            AppLink: t
        })
    }
    ;
    Ovx.IOS.OpenAppLink = function(t) {
        n("IOS.OpenAppLink", {
            AppLink: t
        })
    }
    ;
    Ovx.ExecuteCallback = function(n) {
        for (var i = new Array(arguments.length), t = 0; t < arguments.length; t++)
            i[t] = arguments[t];
        setTimeout(function() {
            var t = ii(Ovx, n);
            typeof t == "function" && t.apply(null, i.slice(1))
        }, 1)
    }
    ;
    wt = !1;
    Ovx.ActiveSupportVieuxNamespaceAndroid = function() {
        Ovx.Device = Ovx.Android.Device;
        wt = !0
    }
}();
