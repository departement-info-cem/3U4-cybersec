
from flask import Flask, render_template, request

app = Flask(__name__)


# create an entry point for /login
@app.route('/login', methods=['POST'])
def login():
    if request.method == 'POST':
        noda = request.form.get('NoDA')
        return f'Received NoDA: {noda}'
    return 'Login'

@app.route('/')
def hello_world():  # put application's code here
    # renvoyer le resultat du template home.html
    return render_template('home.html')
    #return 'Hello World!'


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5555)
